package com.co.kr.free.service;

import java.util.List;
import java.util.Map;

import com.co.kr.free.vo.FreeVo;

public interface FreeService {

	public Map<String, Object> freeBoardList();

}
