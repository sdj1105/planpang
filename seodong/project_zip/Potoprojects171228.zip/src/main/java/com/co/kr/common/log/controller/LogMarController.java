package com.co.kr.common.log.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LogMarController extends HandlerInterceptorAdapter {

	private Log log = LogFactory.getLog(LogMarController.class);

	// 요청전 실행
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		boolean result = false;
		boolean check = false;

		HttpSession session = request.getSession(false);

		String requestUri = request.getRequestURI(); // ex) www.naver.com/?id=sdj1105?pass=ssdj1105 ?를 2개를 만남
													// uri가 이후부터 나오는거고, url이 다나오는거고
		if (!requestUri.equals("/")) {
			String uriTemp ="";
			if (requestUri.indexOf("?") > 0) {
				         // 인덱스를 확인 ?가 하나만있으면 1이면서 get방식
						 // 인덱스를 확인  ?가 하나만있으면 0이면서 get방식
				uriTemp = requestUri.substring(0, requestUri.indexOf("?"));
			} else {
				uriTemp = requestUri;
			}

			String [] uriData = uriTemp.split("/");

			// 인터셉트 타다, 안타다
			System.out.println("체크햇나보자");
			String [] excludeSubDir = {"login"}; // 체크페이지 디렉토리 - 인터셉터를 타다
			String [] excludePage   = {"login.do", "loginCheck.do", "singup.do",
									   "userCreateSuccess.do", "createIdCheck.do", "createEmailCheck.do", "createIdAndEmailCheck.do"
									   ,"mainPage.do", "freeBoard.do", "main2.do"};
									    // 인터셉터를 체크하지않을 페이지를 기입, 로그인 권한이 필요없이 들어가는 페이지  - 인터셉터를 안타다

			if (uriData.length > 0) {
				for (int j = 0; j < excludePage.length; j++) {
					if (uriData[uriData.length-1].equals(excludePage[j])) {
						// uriData가 배열인데
						// uriData.length-1가 마지막페이지를 나타낸다고
						check = true;
					}
				}
			}
				}else{
						check = true;
					}

			      if(check != true) {
			          if(session == null) {
			             response.sendRedirect("/login.do?GBN=SESSIONOUT");
			          } else {
			             if(session.getAttribute("inputId") == null) {
			                response.sendRedirect("/login.do?GBN=SESSIONOUT");
			             } else {
			                result = true;
			             }
			          }
			       }else {
		                result = true;
		             }

					 System.out.println("스터디 인터셉터 시작......");

		return result;
	}

    // 요청후 실행 방법 01
/*	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		super.postHandle(request, response, handler, modelAndView);
		System.out.println("스터디 인터셉터 끝......");
	}*/

	// 요청후 실행 방법 02
   @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        super.afterCompletion(request, response, handler, ex);
    }





}
