package com.blueberry.mybatis;

import java.util.ArrayList;
import java.util.HashMap;


public interface MyPlanBbsMapper {	
	//게시판 목록 
	public ArrayList<HashMap<String, Object>> getArticleList(HashMap<String, Object> hashmap); 
	/** 게시글 추가 */
	public void insertArticle(HashMap<String, Object> hashmap);
	/** 게시글 삭제 */
	public void deleteArticle(HashMap<String, Object> hashmap);
	/** 게시물 수 */
	public int getTotalArticleCnt(HashMap<String, Object> hashmap);
	
	public void del(HashMap<String, Object> hashmap);
	
	public void addcnt(HashMap<String, Object> hashmap);
	
	public void del2(HashMap<String, Object> hashmap);
	
}
